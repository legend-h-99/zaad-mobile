# عرض العائلة ومقدمي الرعاية / Family And Caregiver Pitch

Prepared: 2026-08-04
Audience: العائلة ومقدمو الرعاية / Family and caregivers

Arabic objective: توضيح كيف يساعد زادك من يطبخ أو يرعى المستخدم بدون كشف كامل ملفه الصحي.
English objective: Show how Zaadk helps the person cooking or caring without exposing the full health file.

## Persuasion Sequence
Family audiences need trust and clarity: lead with care burden, then shared routine, then privacy controls.

## Slide Structure

### 1. من يطبخ يحتاج سياقا / The person cooking needs context
ملاحظات الوجبة أهم من كشف الملف الصحي الكامل.
Meal context matters more than exposing the full health record.

### 2. مشاركة بسيطة / Simple sharing
خطة اليوم والممنوعات وملاحظات الملح والسوائل.
Today's meals, restrictions, salt, and hydration notes.

### 3. خصوصية أولا / Privacy first
مشاركة محدودة ومفهومة حسب الدور.
Limited role-based sharing.

### 4. التزام منزلي / Household adherence
الخطة تنجح عندما يفهمها من يشارك في الطعام.
Plans work better when the household understands them.

## Evidence Needed Before External Use

- sharing permissions
- caregiver roles
- privacy copy
- family usage examples

## Readiness
- Zaadk only: yes.
- Source posture: product-grounded, metrics need source.
- External readiness: working draft only.
- Public equity actionability: not actionable without ticker.
