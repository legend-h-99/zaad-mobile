# عرض المستثمرين / Investor Pitch

Prepared: 2026-08-04
Audience: المستثمرون / Investors

Arabic objective: بناء قصة استثمارية حول منتج تغذية علاجية عربي قابل للاستخدام المتكرر والتوسع.
English objective: Build an investment story around Arabic-first therapeutic nutrition with repeat-use and scale potential.

## Persuasion Sequence
Investors are skeptical/executive: lead with risk and opportunity, then retention proof, business model, and ask.

## Slide Structure

### 1. المشكلة والسوق / Problem and market
الصحة الغذائية اليومية في المنطقة العربية تحتاج منتجا محليا موثوقا.
Daily health nutrition in Arabic markets needs trusted local product.

### 2. المنتج المتكامل / Integrated product
ملف صحي، وجبات، وصفات، تحاليل، تتبع، عائلة، استشارة.
Profile, meals, recipes, reports, tracking, family, consultation.

### 3. إثبات التفاعل / Engagement proof
MAU وretention والالتزام بالخطة هي بوابة الاستثمار.
MAU, retention, and adherence are the investment gate.

### 4. النموذج المالي / Financial model
الإيراد يجب أن يتبع الثقة: اشتراك، استشارة، شراكات.
Revenue should follow trust: subscription, consultation, partnerships.

### 5. الطلب / Ask
مبلغ التمويل واستخدامه ومحطات الإثبات التالية.
Funding ask, use of proceeds, and next proof milestones.

## Evidence Needed Before External Use

- MAU
- retention cohorts
- revenue
- CAC
- gross margin
- runway
- funding ask

## Readiness
- Zaadk only: yes.
- Source posture: product-grounded, metrics need source.
- External readiness: working draft only.
- Public equity actionability: not actionable without ticker.
